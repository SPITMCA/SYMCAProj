package com.example.parkarsecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity {
    Button in,out,manual,logout,translate;
    FirebaseAuth mauth;
    DatabaseReference db;
    String ID , security_name, security_phone,curuid,sec_society;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        in = findViewById(R.id.in_btn);
       out = findViewById(R.id.out_btn);
       manual = findViewById(R.id.Manual);
       logout = findViewById(R.id.logout_btn);
       translate = findViewById(R.id.translate);


        mauth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance().getReference("user/security");
        curuid = mauth.getCurrentUser().getUid();
        db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {



                if (snapshot.exists()){
                    for(DataSnapshot id:snapshot.getChildren()){
                         ID = id.child("uid").getValue().toString();
                         if(curuid.equals(ID)) {
                             security_name = id.child("security_name").getValue().toString();
                             security_phone = id.child("security_phone").getValue().toString();
                             sec_society = id.child("security_societycode").getValue().toString();
                         }else{
                             mauth.signOut();
                             startActivity(new Intent(getApplicationContext(),MainActivity.class));
                             Toast.makeText(Home.this, "Not Valid User", Toast.LENGTH_SHORT).show();

                         }


                        }

                    }

            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
            });

       in.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
            Intent i = new Intent(getApplicationContext(),ViewOption.class);
            i.putExtra("from","IN");
               i.putExtra("society_code",sec_society);
            startActivity(i);
           }
       });

       out.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(getApplicationContext(),ViewOption.class);
               i.putExtra("from","OUT");
               i.putExtra("society_code",sec_society);
               startActivity(i);
           }
       });
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ManualLog.class);
                i.putExtra("society_code", sec_society);
                i.putExtra("translate",translate.getText());
                startActivity(i);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mauth.signOut();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });

        translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(Home.this, "हि",Toast.LENGTH_SHORT).show();
                if(translate.getText().equals("En")) {
                   // Toast.makeText(Home.this, "im here", Toast.LENGTH_SHORT).show();
                    translate.setText(R.string.hindi);
                    in.setText(R.string.in_english);
                    out.setText(R.string.out_english);
                    manual.setText(R.string.manual_english);
                    logout.setText(R.string.logout_english);

                }else if(translate.getText().equals("हिं"))
                {
                    translate.setText(R.string.english);
                    in.setText(R.string.in_hindi);
                    out.setText(R.string.out_hindi);
                    manual.setText(R.string.manual_hindi);
                    logout.setText(R.string.logout_hindi);
                }
            }
        });

    }
}