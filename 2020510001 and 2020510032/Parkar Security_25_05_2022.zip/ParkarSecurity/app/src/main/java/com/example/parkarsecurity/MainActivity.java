package com.example.parkarsecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    TextInputEditText email,password;
    Button login,translate;
    private FirebaseAuth mAuth;
    ProgressDialog mdialog;
    DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mdialog  = new ProgressDialog(MainActivity.this);
        mdialog.setTitle("Login");
        mdialog.setMessage("Logging in Please wait");
        email = findViewById(R.id.email_id);
        password = findViewById(R.id.password);
        login = findViewById(R.id.button);
        mAuth = FirebaseAuth.getInstance();
        translate = findViewById(R.id.translate1);



        if(mAuth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),Home.class));
        }
        db = FirebaseDatabase.getInstance().getReference("user/security");
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String memail = email.getText().toString().trim();
                String mpass = password.getText().toString().trim();
                if (TextUtils.isEmpty(memail)) {
                    email.setError("required Field...");
                    return;
                } else if (TextUtils.isEmpty(mpass)) {
                    password.setError("Required Field");
                    return;
                } else {
                    mdialog.setMessage("Processing..");
                    mdialog.show();
                    //Sign in with email and password
                    mAuth.signInWithEmailAndPassword(memail, mpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                mdialog.dismiss();
                               startActivity(new Intent(getApplicationContext(), Home.class));
                                Toast.makeText(getApplicationContext(), "login complete", Toast.LENGTH_SHORT).show();
                            } else {
                                mdialog.dismiss();
                                Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }

            }
        });
        translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(Home.this, "हि",Toast.LENGTH_SHORT).show();
                if(translate.getText().equals("En")) {
                    // Toast.makeText(Home.this, "im here", Toast.LENGTH_SHORT).show();
                    translate.setText(R.string.hindi);
                   login.setText(R.string.login_english);
                   email.setText(R.string.email_english);
                    password.setText(R.string.password_english);

                }else if(translate.getText().equals("हिं"))
                {
                    translate.setText(R.string.english);
                    login.setText(R.string.login_hindi);
                    email.setText(R.string.email_hindi);
                    password.setText(R.string.password_hindi);

                }
            }
        });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email.setText(" ");
            }
        });

        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password.setText(" ");
            }
        });

    }
}