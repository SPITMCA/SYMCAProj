package com.example.parkarsecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.parkarsecurity.model.securityModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ManualLog extends AppCompatActivity {

    Button in,out;
    TextInputEditText veh_no,owner_name;
    String vehicle_number , vehicle_owner  , log_date, log_time ,sec_society,translate;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_log);

        in = findViewById(R.id.manual_in);
        out = findViewById(R.id.manual_out);
        veh_no = findViewById(R.id.Vehicle_no);
        owner_name = findViewById(R.id.owner_name);
        sec_society = getIntent().getStringExtra("society_code");
        translate = getIntent().getStringExtra("translate");

        if(translate.equals("हिं")) {
            // Toast.makeText(Home.this, "im here", Toast.LENGTH_SHORT).show();

            in.setText(R.string.in_english);
            out.setText(R.string.out_english);
            veh_no.setText(R.string.car_no_english);
            owner_name.setText(R.string.car_owner_english);

        }else if(translate.equals("En"))
        {

            in.setText(R.string.in_hindi);
            out.setText(R.string.out_hindi);
            veh_no.setText(R.string.car_no_hindi);
            owner_name.setText(R.string.car_owner_hindi);
        }



        mAuth = FirebaseAuth.getInstance();

        in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat sdtime = new SimpleDateFormat("HH:mm:ss");

                log_date = sdf.format(c.getTime());
                log_time = sdtime.format(c.getTime());

                vehicle_number  = veh_no.getText().toString();
                vehicle_owner = owner_name.getText().toString();
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                DatabaseReference myRef = database.getReference("society/log/"+sec_society);
                String id = myRef.push().getKey().toString();
                 myRef = database.getReference("society/log/"+sec_society+"/"+id);

                securityModel model = new securityModel(id,mAuth.getCurrentUser().getDisplayName(),vehicle_owner,vehicle_number,log_date,log_time,"IN");
                myRef.setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(ManualLog.this, "Log Added", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),Home.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ManualLog.this,"Try Again",Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });

        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat sdtime = new SimpleDateFormat("HH:mm:ss");

                log_date = sdf.format(c.getTime());
                log_time = sdtime.format(c.getTime());

                vehicle_number  = veh_no.getText().toString();
                vehicle_owner = owner_name.getText().toString();
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                DatabaseReference myRef = database.getReference("society/log/"+sec_society);
                String id = myRef.push().getKey().toString();
                myRef = database.getReference("society/log/"+sec_society+"/"+id);

                securityModel model = new securityModel(id,mAuth.getCurrentUser().getDisplayName(),vehicle_owner,vehicle_number,log_date,log_time,"OUT");
                myRef.setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(ManualLog.this, "Log Added", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),Home.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ManualLog.this,"Try Again",Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });


    veh_no.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            veh_no.setText(" ");
        }
    });
        veh_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veh_no.setText(" ");
            }
        });

        owner_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                owner_name.setText(" ");
            }
        });
    }
}