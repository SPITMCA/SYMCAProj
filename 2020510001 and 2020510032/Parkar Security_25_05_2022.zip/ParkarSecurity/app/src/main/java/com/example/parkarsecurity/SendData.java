package com.example.parkarsecurity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.parkarsecurity.model.securityModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SendData extends AppCompatActivity {
    String time , log_date ,sec_society , log_type,vehicle_number,vehicle_owner;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_data);

        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdtime = new SimpleDateFormat("HH:mm:ss");

        log_date = sdf.format(c.getTime());
        time = sdtime.format(c.getTime());

        log_type = getIntent().getStringExtra("log_type");
        sec_society = getIntent().getStringExtra("sec_society");
        vehicle_number = getIntent().getStringExtra("vehicle_number");

        auth = FirebaseAuth.getInstance();
        FirebaseDatabase mydb = FirebaseDatabase.getInstance();
        DatabaseReference mydbRef = mydb.getReference("vehicle/"+vehicle_number);


        mydbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    vehicle_owner = snapshot.child("vehicle_owner").getValue().toString();
                    FirebaseDatabase database = FirebaseDatabase.getInstance();

                    DatabaseReference myRef = database.getReference("society/log/"+sec_society);
                    String id = myRef.push().getKey().toString();
                    myRef = database.getReference("society/log/"+sec_society+"/"+id);
                    securityModel model = new securityModel(id,auth.getCurrentUser().getDisplayName(),vehicle_owner,vehicle_number,log_date,time,log_type);

                    myRef.setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(SendData.this, "Log Added", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),Home.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(SendData.this,"Try Again",Toast.LENGTH_SHORT).show();

                        }
                    });
                }
                Toast.makeText(SendData.this,"vehicle_owner inside "+vehicle_owner, Toast.LENGTH_SHORT).show();

            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });





       // Toast.makeText(SendData.this,"vehicle_owner outside "+xyz, Toast.LENGTH_SHORT).show();




    }
    }