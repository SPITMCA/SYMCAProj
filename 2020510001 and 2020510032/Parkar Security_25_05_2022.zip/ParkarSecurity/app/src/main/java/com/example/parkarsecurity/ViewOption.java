package com.example.parkarsecurity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.parkarsecurity.model.securityModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ViewOption extends AppCompatActivity {
    private FirebaseAuth mAuth;
    String time , log_date ,sec_society , log_type;
     String vehicle_owner ,xyz = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_option);

        SomeFunction();
        mAuth = FirebaseAuth.getInstance();
        log_type = getIntent().getStringExtra("from");
        sec_society = getIntent().getStringExtra("society_code");

    }

    public void SomeFunction(){
        IntentIntegrator intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.setPrompt("Scan a barcode or QR Code");
        intentIntegrator.setOrientationLocked(true);
        intentIntegrator.initiateScan();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        // if the intentResult is null then
        // toast a message as "cancelled"
        if (intentResult != null) {
            if (intentResult.getContents() == null) {
                Toast.makeText(getBaseContext(), "Cancelled", Toast.LENGTH_SHORT).show();
            } else {
                // if the intentResult is not null we'll set
                // the content and format of scan message
//                messageText.setText(intentResult.getContents());
//                messageFormat.setText(intentResult.getFormatName());

                Uri uri = Uri.parse(intentResult.getContents());
                String car_no = uri.getQueryParameter("veh_no");
                Toast.makeText(this, car_no, Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(),SendData.class);
                i.putExtra("vehicle_number",car_no);
                i.putExtra("sec_society",sec_society);
                i.putExtra("log_type",log_type);
                startActivity(i);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

}