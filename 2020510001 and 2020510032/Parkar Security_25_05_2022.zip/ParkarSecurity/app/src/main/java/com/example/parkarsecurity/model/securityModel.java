package com.example.parkarsecurity.model;

public class securityModel {
    String log_id;
    String sec_name;
    String vehicle_owner;
    String vehicle_number;
    String log_date;
    String log_time;

    public String getLog_type() {
        return log_type;
    }

    public void setLog_type(String log_type) {
        this.log_type = log_type;
    }

    String log_type;

    public String getLog_id() {
        return log_id;
    }

    public void setLog_id(String log_id) {
        this.log_id = log_id;
    }

    public String getSec_name() {
        return sec_name;
    }

    public void setSec_name(String sec_name) {
        this.sec_name = sec_name;
    }

    public String getVehicle_owner() {
        return vehicle_owner;
    }

    public void setVehicle_owner(String vehicle_owner) {
        this.vehicle_owner = vehicle_owner;
    }

    public String getVehicle_number() {
        return vehicle_number;
    }

    public void setVehicle_number(String vehicle_number) {
        this.vehicle_number = vehicle_number;
    }

    public String getLog_date() {
        return log_date;
    }

    public void setLog_date(String log_date) {
        this.log_date = log_date;
    }

    public String getLog_time() {
        return log_time;
    }

    public void setLog_time(String log_time) {
        this.log_time = log_time;
    }

    public securityModel(String log_id,String sec_name,String vehicle_owner,String vehicle_number,String log_date,String log_time, String log_type)
    {
        this.log_id =log_id;
        this.sec_name = sec_name;
        this.vehicle_owner= vehicle_owner;
        this.vehicle_number = vehicle_number;
        this.log_date = log_date;
        this.log_time= log_time;
        this.log_type = log_type;
    }
}
