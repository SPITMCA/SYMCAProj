export const environment = {
  production: true,
   firebaseConfig : {
    apiKey: "AIzaSyC_HxoiWw8y91fa5Fif54qMUFS5PcpUbrw",
    authDomain: "finproj-f5b8e.firebaseapp.com",
    projectId: "finproj-f5b8e",
    storageBucket: "finproj-f5b8e.appspot.com",
    messagingSenderId: "523522586061",
    appId: "1:523522586061:web:445b96c91b43e2e41b4084",
    measurementId: "G-508SEV4P99"
  }
};
