import './Glass.css'
import { useState } from 'react'
import axios from 'axios'

function Glass() {
  const [Pregnancies, setPregnancies] = useState('')
  const [Glucose, setGlucose] = useState('')
  const [BloodPressure, setBloodPressure] = useState('')
  const [SkinThickness, setSkinThickness] = useState('')
  const [Insulin, setInsulin] = useState('')
  const [BMI, setBMI] = useState('')
  const [DiabetesPedigreeFunction, setDiabetesPedigreeFunction] = useState('')
  const [Age, setAge] = useState('')
  
  

  const handleSubmit = (e) => {
    e.preventDefault()
    const params = { Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin ,BMI , DiabetesPedigreeFunction , Age}

    axios
      .post('http://localhost:8080/prediction', params)
      .then((res) => {
        const data = res.data.data
        const parameters = JSON.stringify(params)
        const msg = `Prediction: ${data.prediction}\nInterpretation: ${data.interpretation}`
        alert(msg)
        reset()
      })
      .catch((error) => alert(`Error: ${error.message}`))
  }

  const reset = () => {
    setPregnancies('')
    setGlucose('')
    setBloodPressure('')
    setSkinThickness('')
    setInsulin('')
    setBMI('')
    setDiabetesPedigreeFunction('')
    setAge('')
  }

  return (
    <div className="glass">
      <form onSubmit={(e) => handleSubmit(e)} className="glass__form">
        <h4>Patient Data</h4>
        <div className="glass__form__group">
          <input
            id="Pregnancies"
            className="glass__form__input"
            placeholder="Enter No of Pregnancies"
            required
            autoFocus
            min="0"
            pattern="[0-9]{0,1}"
            title="Enter No of Pregnancies"
            type="number"
            value={Pregnancies}
            onChange={(e) => setPregnancies(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="Glucose"
            className="glass__form__input"
            placeholder=" Enter Glucose level"
            required
            type="number"
            title=" Glucose level"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={ Glucose }
            onChange={(e) => setGlucose(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="BloodPressure"
            className="glass__form__input"
            placeholder="Enter BloodPressure Value"
            required
            type="number"
            title="Enter BloodPressure Value"
            value={BloodPressure}
            onChange={(e) => setBloodPressure(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="SkinThickness"
            className="glass__form__input"
            placeholder="Enter SkinThickness value"
            required
            type="number"
            title="Enter SkinThickness value"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={SkinThickness}
            onChange={(e) => setSkinThickness(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="Insulin"
            className="glass__form__input"
            placeholder="Enter Insulin level"
            required
            type="number"
            title="Enter Insulin level"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={Insulin}
            onChange={(e) => setInsulin(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="BMI"
            className="glass__form__input"
            placeholder="Enter your BMI"
            required
            type="number"
            title="Enter your BMI"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={BMI}
            onChange={(e) => setBMI(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="DiabetesPedigreeFunction"
            className="glass__form__input"
            placeholder="Enter Diabetes Pedigree Function value"
            required
            type="number"
            title="Enter Diabetes Pedigree Function value"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={DiabetesPedigreeFunction}
            onChange={(e) => setDiabetesPedigreeFunction(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <input
            id="Age"
            className="glass__form__input"
            placeholder="Enter your age"
            required
            type="number"
            title="Enter your age"
            pattern="[0-9]+([\.,][0-9]+)?"
            step="0.01"
            value={Age}
            onChange={(e) => setAge(e.target.value)}
          />
        </div>

        <div className="glass__form__group">
          <button type="submit" className="glass__form__btn">
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}

export default Glass